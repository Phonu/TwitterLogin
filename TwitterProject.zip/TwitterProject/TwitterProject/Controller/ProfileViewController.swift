//
//  ProfileViewController.swift
//  TwitterProject
//
//  Created by Kunal Poddar on 26/05/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit
import TwitterKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var profileName: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var profileEmailAddress: UILabel!
    @IBOutlet weak var followersBtn: UIButton!
    @IBOutlet weak var followingBtn: UIButton!
    
    var UsersFollowersArray:[[String:Any]] = []
    var UsersFollowingArray:[[String:Any]] = []
    var btnClicked:String = ""

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        profileName.text = UserDefaults.standard.value(forKey: "userName") as? String
        profileEmailAddress.text = UserDefaults.standard.value(forKey: "emailId") as? String
        
        DispatchQueue.global(qos: .background).async {
            do
            {
                let data = try Data.init(contentsOf: URL.init(string:UserDefaults.standard.value(forKey: "profileImageLargeURL") as! String)!)
                DispatchQueue.main.async {
                    let image: UIImage = UIImage(data: data)!
                    self.profileImage.image = image
                }
            }
            catch {
                // error
                print("Error", error)
            }
        }
        self.getFollowers(screenName: (UserDefaults.standard.value(forKey: "screenName") as? String)!)
        self.getFriendslist(screenName: (UserDefaults.standard.value(forKey: "screenName") as? String)!)
        
    }
    
    func getFollowers(screenName : String){
        let userId  = UserDefaults.standard.value(forKey: "userId") as! String
        let client = TWTRAPIClient(userID: userId)
        let url = "https://api.twitter.com/1.1/followers/list.json"
        let params = ["screen_name": screenName,"user_id":userId]
        var clientError : NSError?
        //let request = Twitter.sharedInstance().APIClient.URLRequestWithMethod("GET", URL: url, parameters: params, error: &clientError)
        let request = client.urlRequest(withMethod: "GET", urlString: url, parameters: params, error: &clientError)
        client.sendTwitterRequest(request) { (response, data, connectionError) -> Void in
            if let someData = data {
                do {
                    let results = try JSONSerialization.jsonObject(with: someData, options: .allowFragments) as! NSDictionary
                    print(results)
                    self.UsersFollowersArray = results.value(forKey: "users") as! [[String : Any]]
                    self.followersBtn.setTitle(String(self.UsersFollowersArray.count) + " Followers", for: .normal)

                } catch {
                    print("Error", error)
                }
            }
        }
    }
    
    func getFriendslist(screenName : String){
        let userId  = UserDefaults.standard.value(forKey: "userId") as! String
        let client = TWTRAPIClient(userID: userId)
        let url = "https://api.twitter.com/1.1/friends/list.json"
        let params = ["screen_name": screenName,"user_id":userId]
        var clientError : NSError?
        //let request = Twitter.sharedInstance().APIClient.URLRequestWithMethod("GET", URL: url, parameters: params, error: &clientError)
        let request = client.urlRequest(withMethod: "GET", urlString: url, parameters: params, error: &clientError)
        client.sendTwitterRequest(request) { (response, data, connectionError) -> Void in
            if let someData = data {
                do {
                    let results = try JSONSerialization.jsonObject(with: someData, options: .allowFragments) as! NSDictionary
                    print(results)
                    self.UsersFollowingArray = results.value(forKey: "users") as! [[String : Any]]
                    self.followingBtn.setTitle(String(self.UsersFollowingArray.count) + " Following", for: .normal)

                    
                } catch {
                    print("Error", error)
                }
            }
        }
    }
    
    @IBAction func followerBtnClicked(_ sender: Any) {
        self.btnClicked = "Followers List"
        self.performSegue(withIdentifier: "followerOrFollowingList", sender: self)    }
    
    @IBAction func followingBtnClicked(_ sender: Any) {
        self.btnClicked = "Following List"
        self.performSegue(withIdentifier: "followerOrFollowingList", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? FollowerOrFollowingList{
            if self.btnClicked == "Followers List"{
                destination.followerOrFollowingList = self.UsersFollowersArray
                destination.tableTitle = self.btnClicked
            } else if self.btnClicked == "Following List" {
                destination.followerOrFollowingList = self.UsersFollowingArray
                destination.tableTitle = self.btnClicked
            }
        }
    }

}
