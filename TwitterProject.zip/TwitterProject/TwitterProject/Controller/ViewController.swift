//
//  ViewController.swift
//  TwitterProject
//
//  Created by Kunal Poddar on 25/05/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit
import TwitterKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.setUpTwitterButton()
    }

    
    fileprivate func setUpTwitterButton(){
        let twitterButton = TWTRLogInButton {  (session , error ) in
            if let err = error{
                print("kunal\(err)")
                return
            }else{
                print("success")
                print(session?.userName ?? "")
                print(session?.userID ?? "")
                
                let twitterClient = TWTRAPIClient(userID: session?.userID)
                twitterClient.loadUser(withID: session?.userID ?? "") {(user, error) in
                    print(user?.profileImageURL ?? "")
                    print(user?.profileImageLargeURL ?? "")
                    print(user?.screenName ?? "")
                    UserDefaults.standard.set(user?.profileImageURL ?? "", forKey: "profileImageURL")
                    UserDefaults.standard.set(user?.profileImageLargeURL ?? "", forKey: "profileImageLargeURL")
                    UserDefaults.standard.set(user?.screenName ?? "", forKey: "screenName")
                }
                
                twitterClient.requestEmail { email, error in
                    if (email != nil) {
                        let recivedEmailID = email ?? ""
                        print(recivedEmailID)
                        UserDefaults.standard.set(recivedEmailID, forKey: "emailId")
                    }else {
                        print("error--: \(String(describing: error?.localizedDescription))");
                    }
                }
                UserDefaults.standard.set(session?.userName ?? "", forKey: "userName")
                UserDefaults.standard.set(session?.userID ?? "", forKey: "userId")
                self.performSegue(withIdentifier: "profileDetail", sender: self)
                
            }
        }
        view.addSubview(twitterButton)
        
        twitterButton.frame = CGRect(x: view.frame.width/2 - twitterButton.frame.width/2 - 20, y: view.frame.height/2 - twitterButton.frame.height/2, width: view.frame.width * 0.8, height: 50)
            
    }
}

