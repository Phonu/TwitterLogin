//
//  FollowerOrFollowingList.swift
//  TwitterProject
//
//  Created by Kunal Poddar on 26/05/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit

class FollowerOrFollowingList: UIViewController {
    
    var followerOrFollowingList:[[String:Any]] = []
    var tableTitle = ""
    var followerFollowingList = [String]()
    var selectedProfileDict = [String:String]()
    @IBOutlet weak var followerFollowingTableView: UITableView!
    @IBOutlet weak var tableName: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableName.text = self.tableTitle
        self.followerFollowingTableView.delegate = self
        self.followerFollowingTableView.dataSource = self
        self.followerFollowingTableView.reloadData()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "eachProfileDetails"{
            if let destination = segue.destination as? EachProfileDetails {
                destination.eachProfileDict = self.selectedProfileDict
            }
        }
    }
}

extension FollowerOrFollowingList : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.followerOrFollowingList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "followerFollowingList")

        DispatchQueue.global(qos: .background).async {
            do
            {
                let data = try Data.init(contentsOf: URL.init(string:self.followerOrFollowingList[indexPath.row]["profile_image_url_https"] as! String)!)
                DispatchQueue.main.async {
                    let image: UIImage = UIImage(data: data)!
                    cell?.imageView?.image = image
                    cell?.textLabel!.text = self.followerOrFollowingList[indexPath.row]["name"] as? String
                }
            }
            catch {
                // error
                print("Error : ", error)
            }
        }
        return cell!
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedProfileDict["profileName"] = self.followerOrFollowingList[indexPath.row]["name"] as? String
        selectedProfileDict["profilePic"] = self.followerOrFollowingList[indexPath.row]["profile_image_url_https"] as? String
        selectedProfileDict["profileFollowers"] = String(self.followerOrFollowingList[indexPath.row]["followers_count"] as! Int)
        selectedProfileDict["profileFollowing"] = String(self.followerOrFollowingList[indexPath.row]["friends_count"] as! Int)
        self.performSegue(withIdentifier: "eachProfileDetails", sender: self)
    }
}
