//
//  EachProfileDetails.swift
//  TwitterProject
//
//  Created by Kunal Poddar on 26/05/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit

class EachProfileDetails: UIViewController {
    
    var eachProfileDict:[String:String] = [:]
    @IBOutlet weak var profilePic: UIImageView!
    @IBOutlet weak var profileName: UILabel!
    @IBOutlet weak var profileFollowers: UILabel!
    @IBOutlet weak var profileFollowing: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(eachProfileDict)
        self.displayProfileDetails()
    }
    
    
    func displayProfileDetails(){
        DispatchQueue.global(qos: .background).async {
            do
            {
                let data = try Data.init(contentsOf: URL.init(string:self.eachProfileDict["profilePic"]!)!)
                DispatchQueue.main.async {
                    let image: UIImage = UIImage(data: data)!
                    self.profilePic.image = image
                    self.profileName.text = self.eachProfileDict["profileName"]
                    self.profileFollowers.text = String(self.eachProfileDict["profileFollowers"]! + " Follower")
                    self.profileFollowing.text = String(self.eachProfileDict["profileFollowing"]! + " Following")
                }
            }
            catch {
                // error
                print("Error : ", error)
            }
        }
    }
}
